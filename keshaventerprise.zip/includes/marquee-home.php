
<section class=" overflow-hidden p-5 ">
  <div class="container-fluid primary-bg">
    <div class="row">
      <div class="col">
        <div class="marquee-wrap marquee_mode">
          <div class="marquee-inner">
            <div class="marquee-text text-white">
              <span>POWER PRESS</span>
              <i class="flaticon flaticon-factory-1"></i>
            </div>
            <div class="marquee-text text-white">
              <span>HYDRAULIC PRESS</span>
              <i class="flaticon flaticon-factory-1"></i>
            </div>
            <div class="marquee-text text-white">
              <span>NC PRESS BRAKE</span>
              <i class="flaticon flaticon-factory-1"></i>
            </div>
            <div class="marquee-text text-white">
              <span>EXPORTS</span>
              <i class="flaticon flaticon-factory-1"></i>
            </div>
            <div class="marquee-text text-white">
              <span>Industry</span>
              <i class="flaticon flaticon-factory-1"></i>
            </div>
            <div class="marquee-text text-white">
              <span>Petroleum</span>
              <i class="flaticon flaticon-factory-1"></i>
            </div>
            <div class="marquee-text text-white">
              <span>Renewable</span>
              <i class="flaticon flaticon-factory-1"></i>
            </div>
            <div class="marquee-text text-white">
              <span>Keshav Enterprise</span>
              <i class="flaticon flaticon-factory-1"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>